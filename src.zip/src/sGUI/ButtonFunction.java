package sGUI;

public interface ButtonFunction {
	public void func();
}
